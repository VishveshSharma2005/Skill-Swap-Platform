from flask import Flask, render_template, request, jsonify, redirect, url_for
import sqlite3
import os
from werkzeug.utils import secure_filename
import base64

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Create uploads directory if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def init_db():
    conn = sqlite3.connect('user_details.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_details (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            location TEXT NOT NULL,
            skills_offer TEXT NOT NULL,
            skills_wanted TEXT NOT NULL,
            availability_start TEXT NOT NULL,
            availability_end TEXT NOT NULL,
            profile_type TEXT NOT NULL,
            profile_picture TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/submit', methods=['POST'])
def submit_form():
    try:
        # Get form data
        name = request.form.get('name', '').strip()
        location = request.form.get('location', '').strip()
        skills_offer = ','.join(request.form.getlist('skills_offer'))
        skills_wanted = ','.join(request.form.getlist('skills_wanted'))
        availability_start = request.form.get('availability_start')
        availability_end = request.form.get('availability_end')
        profile_type = request.form.get('profile_type')
        
        # Handle profile picture
        profile_picture = None
        if 'profile_picture' in request.files:
            file = request.files['profile_picture']
            if file and file.filename:
                # Convert to base64 for database storage
                profile_picture = base64.b64encode(file.read()).decode('utf-8')
        
        # Validate required fields
        if not all([name, location, skills_offer, skills_wanted, availability_start, availability_end, profile_type]):
            return jsonify({'success': False, 'message': 'All fields are required'})
        
        # Save to database
        conn = sqlite3.connect('user_details.db')
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO user_details 
            (name, location, skills_offer, skills_wanted, availability_start, availability_end, profile_type, profile_picture)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (name, location, skills_offer, skills_wanted, availability_start, availability_end, profile_type, profile_picture))
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Form submitted successfully!'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
