# User Details Form

A simple web application with Flask backend and SQLite database for collecting user details.

## Features

- **Name**: Text input with 20 character limit
- **Location**: Text input with 20 character limit  
- **Skills Offered**: Multi-select dropdown (Graphic Design, Video Editing, Coder, Photoshop)
- **Skills Wanted**: Multi-select dropdown (Graphic Design, Video Editing, Coder, Photoshop)
- **Availability**: Date range picker
- **Profile Type**: Radio buttons (Public/Private)
- **Profile Picture**: Upload image that displays in a 150px circular frame

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the application:
   ```bash
   python app.py
   ```

3. Open your browser and go to `http://localhost:5000`

## Database

The application uses SQLite database (`user_details.db`) to store all form submissions. The database is automatically created when you first run the application.

## File Structure

```
├── app.py                 # Flask backend
├── requirements.txt       # Python dependencies
├── templates/
│   └── form.html         # HTML form with embedded CSS and JavaScript
├── static/
│   └── uploads/          # Directory for uploaded files
└── user_details.db       # SQLite database (created automatically)
```
